import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../online/car_tab_location.dart';
import '../online/car_tab_price.dart';

class CarGridScreen extends StatefulWidget {
  const CarGridScreen({super.key});



  @override
  State<CarGridScreen> createState() => _CarGridScreenState();
}

class _CarGridScreenState extends State<CarGridScreen> {
  final TextEditingController _searchController = TextEditingController();
  String _searchText = "";
  List<DocumentSnapshot> _cars = [];
  List<DocumentSnapshot> _filteredCars = [];



  @override
  void initState() {
    super.initState();
    FirebaseFirestore.instance
        .collection('cars')
        .get()
        .then((QuerySnapshot snapshot) {
      setState(() {
        _cars = snapshot.docs;
        _filteredCars = _cars;
      });
    });
  }



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).primaryColor.withOpacity(0.8),
        title: TextField(
          controller: _searchController,
          decoration: const InputDecoration(
            hintText: "Type Car Name",
            hintStyle: TextStyle(color: Colors.white,),
            border: InputBorder.none,
          ),
            onChanged: (value) {
              setState(() {
                _searchText = value;
                _filteredCars = _cars.where((car) {
                  final name = car['name'] as String;
                  final modelyear = car['modelyear'] as String;
                  final searchText = _searchText.toLowerCase();
                  return name.toLowerCase().contains(searchText) ||
                      modelyear.toLowerCase().contains(searchText);
                }).toList();
              });
            },




        ),
        actions: [


        ],


      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance.collection('cars').snapshots(),
        builder: (BuildContext context, AsyncSnapshot<QuerySnapshot> snapshot) {
          if (!snapshot.hasData) {
            return const Center(
              child: CircularProgressIndicator(),
            );
          }

          return GridView.builder(
            itemCount: snapshot.data?.docs.length,
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              childAspectRatio: 2 / 2,
              mainAxisSpacing: 2,
              crossAxisSpacing: 10,
            ),
            itemBuilder: (BuildContext context, int index) {
              DocumentSnapshot document = snapshot.data!.docs[index];
              return InkWell(
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => CarDetailScreen(document),
                    ),
                  );
                },
                child: Card(
                  child: Stack(
                    alignment: Alignment.topCenter,
                    children: <Widget>[

                      Container(
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(10.0),
                          boxShadow: const [
                            BoxShadow(
                              color: Colors.black26,
                              offset: Offset(0.0, 2.0),
                              blurRadius: 6.0,
                            ),
                          ],
                        ),
                        child: Hero(
                          tag:  document['imageurl'],
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(10.0),
                            child: Image(
                              height: 180.0,
                              width: 180.0,
                              image: AssetImage(document['imageurl']),
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                      ),
                      Positioned(
                        bottom: 35,
                        left: 5,
                        child: Container(
                          decoration: BoxDecoration(
                            color: Theme.of(context).primaryColor.withOpacity(0.8),
                            borderRadius: BorderRadius.circular(2),
                          ),


                          child: Wrap(
                            children: [
                              Text(
                                document['name'],
                                style: GoogleFonts.bebasNeue(
                                  color: Colors.white,
                                  fontSize: 18.0,
                                  fontWeight: FontWeight.w500,
                                  letterSpacing: 1.2,
                                ),
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ],
                          ),
                        ),
                      ),
                      Positioned(
                        bottom: 5,
                        left: 5,
                        child: Container(
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(2),
                          ),


                          child: Wrap(
                            children: [
                              Text(
                                document['address'],
                                style: GoogleFonts.bebasNeue(
                                  color: Theme.of(context).primaryColor.withOpacity(0.8),
                                  fontSize: 18.0,
                                  fontWeight: FontWeight.w500,
                                  // letterSpacing: 1.2,
                                ),
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ],
                          ),
                        ),
                      ),
                      Positioned(
                        top: 5,
                        right: 5,
                        child: Container(
                          decoration: BoxDecoration(
                            color: Theme.of(context).primaryColor.withOpacity(0.8),
                            borderRadius: BorderRadius.circular(2),
                          ),


                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [

                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [

                                  Text(
                                    document['price'].toString(),
                                    style: GoogleFonts.bebasNeue(
                                      color: Colors.white,
                                      fontWeight: FontWeight.w600,
                                    ),
                                  ),

                                ],
                              ),
                            ],
                          ),
                        ),
                      ),
                      Positioned(
                        top: 5,
                        left: 5,
                        child: Container(
                          decoration: BoxDecoration(
                            color: Theme.of(context).primaryColor.withOpacity(0.8),
                            borderRadius: BorderRadius.circular(2),
                          ),


                          child: Padding(
                            padding: const EdgeInsets.all(2.0),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [

                                Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    Row(
                                      children: [
                                        const Icon(Icons.luggage_outlined,size: 15,),
                                        Text(
                                          document['luggage'].toString(),
                                          style: GoogleFonts.bebasNeue(
                                            color: Colors.white,

                                            fontWeight: FontWeight.w600,
                                          ),
                                        ),
                                      ],
                                    ),
                                    const SizedBox(width: 10,),
                                    Row(
                                      children: [
                                        const Icon(Icons.person_2,size: 15,),
                                        Text(
                                          document['pass'].toString(),
                                          style: GoogleFonts.bebasNeue(
                                            color: Colors.white,

                                            fontWeight: FontWeight.w600,
                                          ),
                                        ),
                                      ],
                                    ),
                                    const SizedBox(width: 10,),
                                    Row(
                                      children: [
                                        const Icon(Icons.door_front_door_outlined,size: 15,),
                                        Text(
                                          'b',
                                          style: GoogleFonts.bebasNeue(
                                            color: Colors.white,

                                            fontWeight: FontWeight.w600,
                                          ),
                                        ),
                                      ],
                                    ),



                                  ],
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),

                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}



class CarDetailScreen extends StatelessWidget {
  final DocumentSnapshot document;

  CarDetailScreen(this.document);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(document['name'] + ' ' + document['modelyear']),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Image.network(
              document['imageurl'],
              height: 200,
              width: 200,
              fit: BoxFit.cover,
            ),
            SizedBox(height: 16),
            Text(
              'Make: ' + document['name'],
              style: TextStyle(fontSize: 18),
            ),
            const SizedBox(height: 8),
            Text(
              'Model: ' + document['modelyear'],
              style: const TextStyle(fontSize: 18),
            ),
            const SizedBox(height: 8),
            Text(
              'Year: ' + document['price'].toString(),
              style: const TextStyle(fontSize: 18),
            ),
            const SizedBox(height: 8),
            Text(
              'Color: ' + document['name'],
              style: TextStyle(fontSize: 18),
            ),
          ],
        ),
      ),
    );
  }
}